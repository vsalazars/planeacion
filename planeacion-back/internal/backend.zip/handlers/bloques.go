package handlers

import (
	"net/http"
	"github.com/gin-gonic/gin"
	"github.com/jackc/pgx/v5/pgxpool"
)

type BloquesHandler struct {
	DB *pgxpool.Pool
}

func RegisterBloquesRoutes(rg *gin.RouterGroup, h *BloquesHandler) {
	rg.POST("/unidades/:unidadID/bloques", h.CreateBloque)
	rg.PUT("/bloques/:id", h.UpdateBloque)
	rg.DELETE("/bloques/:id", h.DeleteBloque)
}

func (h *BloquesHandler) CreateBloque(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"msg": "crear bloque"})
}

func (h *BloquesHandler) UpdateBloque(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"msg": "actualizar bloque"})
}

func (h *BloquesHandler) DeleteBloque(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"msg": "eliminar bloque"})
}
