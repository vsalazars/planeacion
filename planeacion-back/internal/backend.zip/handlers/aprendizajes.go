package handlers

import (
	"net/http"
	"github.com/gin-gonic/gin"
	"github.com/jackc/pgx/v5/pgxpool"
)

type AprendizajesHandler struct {
	DB *pgxpool.Pool
}

func RegisterAprendizajesRoutes(rg *gin.RouterGroup, h *AprendizajesHandler) {
	rg.POST("/unidades/:unidadID/aprendizajes", h.CreateAprendizaje)
	rg.PUT("/aprendizajes/:id", h.UpdateAprendizaje)
	rg.DELETE("/aprendizajes/:id", h.DeleteAprendizaje)
}

func (h *AprendizajesHandler) CreateAprendizaje(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"msg": "crear aprendizaje"})
}

func (h *AprendizajesHandler) UpdateAprendizaje(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"msg": "actualizar aprendizaje"})
}

func (h *AprendizajesHandler) DeleteAprendizaje(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"msg": "eliminar aprendizaje"})
}
