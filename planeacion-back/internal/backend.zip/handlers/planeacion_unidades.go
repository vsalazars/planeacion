package handlers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/jackc/pgx/v5/pgxpool"
)

type PlaneacionUnidadesHandler struct {
	DB *pgxpool.Pool
}

// Registra las rutas relacionadas con unidades temáticas de una planeación
func RegisterPlaneacionUnidadesRoutes(rg *gin.RouterGroup, h *PlaneacionUnidadesHandler) {
	// 👇 importante: usar el MISMO wildcard que /api/planeaciones/:id
	rg.POST("/planeaciones/:id/unidades", h.CreateUnidadTematica)
	rg.GET("/planeaciones/:id/unidades", h.ListUnidadesTematicas)

	// CRUD por id de unidad temática (no hay conflicto aquí)
	rg.GET("/planeaciones/unidades/:id", h.GetUnidadTematica)
	rg.PUT("/planeaciones/unidades/:id", h.UpdateUnidadTematica)
	rg.DELETE("/planeaciones/unidades/:id", h.DeleteUnidadTematica)
}

func (h *PlaneacionUnidadesHandler) CreateUnidadTematica(c *gin.Context) {
	planeacionID := c.Param("id")
	c.JSON(http.StatusOK, gin.H{
		"msg":           "crear unidad temática",
		"planeacion_id": planeacionID,
	})
}

func (h *PlaneacionUnidadesHandler) ListUnidadesTematicas(c *gin.Context) {
	planeacionID := c.Param("id")
	c.JSON(http.StatusOK, gin.H{
		"msg":           "listar unidades temáticas",
		"planeacion_id": planeacionID,
	})
}

func (h *PlaneacionUnidadesHandler) GetUnidadTematica(c *gin.Context) {
	id := c.Param("id")
	c.JSON(http.StatusOK, gin.H{
		"msg":           "obtener unidad temática",
		"unidad_id":     id,
	})
}

func (h *PlaneacionUnidadesHandler) UpdateUnidadTematica(c *gin.Context) {
	id := c.Param("id")
	c.JSON(http.StatusOK, gin.H{
		"msg":           "actualizar unidad temática",
		"unidad_id":     id,
	})
}

func (h *PlaneacionUnidadesHandler) DeleteUnidadTematica(c *gin.Context) {
	id := c.Param("id")
	c.JSON(http.StatusOK, gin.H{
		"msg":           "eliminar unidad temática",
		"unidad_id":     id,
	})
}
