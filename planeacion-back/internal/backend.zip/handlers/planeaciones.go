package handlers

import (
	"errors"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

type PlaneacionesHandler struct {
	DB *pgxpool.Pool
}

func RegisterPlaneacionesRoutes(rg *gin.RouterGroup, h *PlaneacionesHandler) {
	rg.POST("/planeaciones", h.CreatePlaneacion)
	rg.GET("/planeaciones/:id", h.GetPlaneacion)
	rg.PUT("/planeaciones/:id", h.UpdatePlaneacion)
	rg.DELETE("/planeaciones/:id", h.DeletePlaneacion)
}

// --------- DTOs ---------

type CreatePlaneacionRequest struct {
	PeriodoEscolar          *string  `json:"periodo_escolar"`
	PlanEstudiosAnio        *int     `json:"plan_estudios_anio"`
	SemestreNivel           *string  `json:"semestre_nivel"`
	Grupos                  *string  `json:"grupos"`
	ProgramaAcademico       *string  `json:"programa_academico"`
	Academia                *string  `json:"academia"`
	UnidadAprendizajeNombre *string  `json:"unidad_aprendizaje_nombre"`
	AreaFormacion           *string  `json:"area_formacion"`
	Modalidad               *string  `json:"modalidad"`

	SesionesPorSemestre *int `json:"sesiones_por_semestre"`
	SesionesAula        *int `json:"sesiones_aula"`
	SesionesLaboratorio *int `json:"sesiones_laboratorio"`
	SesionesClinica     *int `json:"sesiones_clinica"`
	SesionesOtro        *int `json:"sesiones_otro"`

	HorasTeoria      *float64 `json:"horas_teoria"`
	HorasPractica    *float64 `json:"horas_practica"`
	HorasAula        *float64 `json:"horas_aula"`
	HorasLaboratorio *float64 `json:"horas_laboratorio"`
	HorasClinica     *float64 `json:"horas_clinica"`
	HorasOtro        *float64 `json:"horas_otro"`
	HorasTotal       *float64 `json:"horas_total"`

	Antecedentes string `json:"antecedentes"`
	Laterales    string `json:"laterales"`
	Subsecuentes string `json:"subsecuentes"`

	EjesCompromisoSocialSustentabilidad string `json:"ejes_compromiso_social_sustentabilidad"`
	EjesPerspectivaGenero               string `json:"ejes_perspectiva_genero"`
	EjesInternacionalizacion            string `json:"ejes_internacionalizacion"`

	OrgProposito string `json:"org_proposito"`
	OrgEstrategia string `json:"org_estrategia"`
	OrgMetodos    string `json:"org_metodos"`

	PlagioIthenticate bool   `json:"plagio_ithenticate"`
	PlagioTurnitin    bool   `json:"plagio_turnitin"`
	PlagioOtro        string `json:"plagio_otro"`
}

// Para devolver algo más limpio (puedes mover esto a internal/models si quieres)
type Planeacion struct {
	ID                      int64     `json:"id"`
	UsuarioID               int       `json:"usuario_id"`
	UnidadID                int       `json:"unidad_id"`
	PeriodoEscolar          *string   `json:"periodo_escolar"`
	PlanEstudiosAnio        *int      `json:"plan_estudios_anio"`
	SemestreNivel           *string   `json:"semestre_nivel"`
	Grupos                  *string   `json:"grupos"`
	ProgramaAcademico       *string   `json:"programa_academico"`
	Academia                *string   `json:"academia"`
	UnidadAprendizajeNombre *string   `json:"unidad_aprendizaje_nombre"`
	AreaFormacion           *string   `json:"area_formacion"`
	Modalidad               *string   `json:"modalidad"`
	SesionesPorSemestre     *int      `json:"sesiones_por_semestre"`
	SesionesAula            *int      `json:"sesiones_aula"`
	SesionesLaboratorio     *int      `json:"sesiones_laboratorio"`
	SesionesClinica         *int      `json:"sesiones_clinica"`
	SesionesOtro            *int      `json:"sesiones_otro"`
	HorasTeoria             *float64  `json:"horas_teoria"`
	HorasPractica           *float64  `json:"horas_practica"`
	HorasAula               *float64  `json:"horas_aula"`
	HorasLaboratorio        *float64  `json:"horas_laboratorio"`
	HorasClinica            *float64  `json:"horas_clinica"`
	HorasOtro               *float64  `json:"horas_otro"`
	HorasTotal              *float64  `json:"horas_total"`
	Antecedentes            string    `json:"antecedentes"`
	Laterales               string    `json:"laterales"`
	Subsecuentes            string    `json:"subsecuentes"`
	EjesCompromisoSocialSustentabilidad string `json:"ejes_compromiso_social_sustentabilidad"`
	EjesPerspectivaGenero               string `json:"ejes_perspectiva_genero"`
	EjesInternacionalizacion            string `json:"ejes_internacionalizacion"`
	OrgProposito string    `json:"org_proposito"`
	OrgEstrategia string   `json:"org_estrategia"`
	OrgMetodos    string   `json:"org_metodos"`
	PlagioIthenticate bool `json:"plagio_ithenticate"`
	PlagioTurnitin    bool `json:"plagio_turnitin"`
	PlagioOtro        string `json:"plagio_otro"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

// --------- Helpers internos para auth ---------

func (h *PlaneacionesHandler) getUserFromToken(c *gin.Context) (*PlaneacionClaims, error) {
	authHeader := c.GetHeader("Authorization")
	if !strings.HasPrefix(authHeader, "Bearer ") {
		return nil, errors.New("token no proporcionado")
	}
	tokenStr := strings.TrimSpace(strings.TrimPrefix(authHeader, "Bearer "))

	secret, err := getJWTSecret()
	if err != nil {
		return nil, err
	}

	token, err := jwt.ParseWithClaims(tokenStr, &PlaneacionClaims{}, func(t *jwt.Token) (interface{}, error) {
		if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, errors.New("algoritmo de firma inválido")
		}
		return []byte(secret), nil
	})
	if err != nil || !token.Valid {
		return nil, errors.New("token inválido")
	}

	claims, ok := token.Claims.(*PlaneacionClaims)
	if !ok {
		return nil, errors.New("claims inválidos")
	}
	return claims, nil
}

// --------- Handlers ---------

// POST /api/planeaciones
func (h *PlaneacionesHandler) CreatePlaneacion(c *gin.Context) {
	claims, err := h.getUserFromToken(c)
	if err != nil {
		c.JSON(http.StatusUnauthorized, gin.H{"error": err.Error()})
		return
	}

	var req CreatePlaneacionRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "payload inválido",
			"msg":   err.Error(),
		})
		return
	}

	ctx := c.Request.Context()

	const insertSQL = `
		INSERT INTO public.planeaciones (
			usuario_id,
			unidad_id,
			periodo_escolar,
			plan_estudios_anio,
			semestre_nivel,
			grupos,
			programa_academico,
			academia,
			unidad_aprendizaje_nombre,
			area_formacion,
			modalidad,
			sesiones_por_semestre,
			sesiones_aula,
			sesiones_laboratorio,
			sesiones_clinica,
			sesiones_otro,
			horas_teoria,
			horas_practica,
			horas_aula,
			horas_laboratorio,
			horas_clinica,
			horas_otro,
			horas_total,
			antecedentes,
			laterales,
			subsecuentes,
			ejes_compromiso_social_sustentabilidad,
			ejes_perspectiva_genero,
			ejes_internacionalizacion,
			org_proposito,
			org_estrategia,
			org_metodos,
			plagio_ithenticate,
			plagio_turnitin,
			plagio_otro
		)
		VALUES (
			$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,
			$12,$13,$14,$15,$16,
			$17,$18,$19,$20,$21,$22,$23,
			$24,$25,$26,
			$27,$28,$29,
			$30,$31,$32,
			$33,$34,$35
		)
		RETURNING
			id,
			usuario_id,
			unidad_id,
			periodo_escolar,
			plan_estudios_anio,
			semestre_nivel,
			grupos,
			programa_academico,
			academia,
			unidad_aprendizaje_nombre,
			area_formacion,
			modalidad,
			sesiones_por_semestre,
			sesiones_aula,
			sesiones_laboratorio,
			sesiones_clinica,
			sesiones_otro,
			horas_teoria,
			horas_practica,
			horas_aula,
			horas_laboratorio,
			horas_clinica,
			horas_otro,
			horas_total,
			antecedentes,
			laterales,
			subsecuentes,
			ejes_compromiso_social_sustentabilidad,
			ejes_perspectiva_genero,
			ejes_internacionalizacion,
			org_proposito,
			org_estrategia,
			org_metodos,
			plagio_ithenticate,
			plagio_turnitin,
			plagio_otro,
			created_at,
			updated_at;
	`

	var p Planeacion

	err = h.DB.QueryRow(
		ctx,
		insertSQL,
		claims.UserID,
		claims.UnidadID,
		req.PeriodoEscolar,
		req.PlanEstudiosAnio,
		req.SemestreNivel,
		req.Grupos,
		req.ProgramaAcademico,
		req.Academia,
		req.UnidadAprendizajeNombre,
		req.AreaFormacion,
		req.Modalidad,
		req.SesionesPorSemestre,
		req.SesionesAula,
		req.SesionesLaboratorio,
		req.SesionesClinica,
		req.SesionesOtro,
		req.HorasTeoria,
		req.HorasPractica,
		req.HorasAula,
		req.HorasLaboratorio,
		req.HorasClinica,
		req.HorasOtro,
		req.HorasTotal,
		req.Antecedentes,
		req.Laterales,
		req.Subsecuentes,
		req.EjesCompromisoSocialSustentabilidad,
		req.EjesPerspectivaGenero,
		req.EjesInternacionalizacion,
		req.OrgProposito,
		req.OrgEstrategia,
		req.OrgMetodos,
		req.PlagioIthenticate,
		req.PlagioTurnitin,
		req.PlagioOtro,
	).Scan(
		&p.ID,
		&p.UsuarioID,
		&p.UnidadID,
		&p.PeriodoEscolar,
		&p.PlanEstudiosAnio,
		&p.SemestreNivel,
		&p.Grupos,
		&p.ProgramaAcademico,
		&p.Academia,
		&p.UnidadAprendizajeNombre,
		&p.AreaFormacion,
		&p.Modalidad,
		&p.SesionesPorSemestre,
		&p.SesionesAula,
		&p.SesionesLaboratorio,
		&p.SesionesClinica,
		&p.SesionesOtro,
		&p.HorasTeoria,
		&p.HorasPractica,
		&p.HorasAula,
		&p.HorasLaboratorio,
		&p.HorasClinica,
		&p.HorasOtro,
		&p.HorasTotal,
		&p.Antecedentes,
		&p.Laterales,
		&p.Subsecuentes,
		&p.EjesCompromisoSocialSustentabilidad,
		&p.EjesPerspectivaGenero,
		&p.EjesInternacionalizacion,
		&p.OrgProposito,
		&p.OrgEstrategia,
		&p.OrgMetodos,
		&p.PlagioIthenticate,
		&p.PlagioTurnitin,
		&p.PlagioOtro,
		&p.CreatedAt,
		&p.UpdatedAt,
	)

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "error al crear planeación",
			"msg":   err.Error(),
		})
		return
	}

	c.JSON(http.StatusCreated, p)
}

// GET /api/planeaciones/:id
func (h *PlaneacionesHandler) GetPlaneacion(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil || id <= 0 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "id inválido"})
		return
	}

	ctx := c.Request.Context()

	const query = `
		SELECT
			id,
			usuario_id,
			unidad_id,
			periodo_escolar,
			plan_estudios_anio,
			semestre_nivel,
			grupos,
			programa_academico,
			academia,
			unidad_aprendizaje_nombre,
			area_formacion,
			modalidad,
			sesiones_por_semestre,
			sesiones_aula,
			sesiones_laboratorio,
			sesiones_clinica,
			sesiones_otro,
			horas_teoria,
			horas_practica,
			horas_aula,
			horas_laboratorio,
			horas_clinica,
			horas_otro,
			horas_total,
			antecedentes,
			laterales,
			subsecuentes,
			ejes_compromiso_social_sustentabilidad,
			ejes_perspectiva_genero,
			ejes_internacionalizacion,
			org_proposito,
			org_estrategia,
			org_metodos,
			plagio_ithenticate,
			plagio_turnitin,
			plagio_otro,
			created_at,
			updated_at
		FROM public.planeaciones
		WHERE id = $1;
	`

	var p Planeacion
	err = h.DB.QueryRow(ctx, query, id).Scan(
		&p.ID,
		&p.UsuarioID,
		&p.UnidadID,
		&p.PeriodoEscolar,
		&p.PlanEstudiosAnio,
		&p.SemestreNivel,
		&p.Grupos,
		&p.ProgramaAcademico,
		&p.Academia,
		&p.UnidadAprendizajeNombre,
		&p.AreaFormacion,
		&p.Modalidad,
		&p.SesionesPorSemestre,
		&p.SesionesAula,
		&p.SesionesLaboratorio,
		&p.SesionesClinica,
		&p.SesionesOtro,
		&p.HorasTeoria,
		&p.HorasPractica,
		&p.HorasAula,
		&p.HorasLaboratorio,
		&p.HorasClinica,
		&p.HorasOtro,
		&p.HorasTotal,
		&p.Antecedentes,
		&p.Laterales,
		&p.Subsecuentes,
		&p.EjesCompromisoSocialSustentabilidad,
		&p.EjesPerspectivaGenero,
		&p.EjesInternacionalizacion,
		&p.OrgProposito,
		&p.OrgEstrategia,
		&p.OrgMetodos,
		&p.PlagioIthenticate,
		&p.PlagioTurnitin,
		&p.PlagioOtro,
		&p.CreatedAt,
		&p.UpdatedAt,
	)

	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{
			"error": "planeación no encontrada",
			"id":    id,
			"msg":   err.Error(),
		})
		return
	}

	c.JSON(http.StatusOK, p)
}

// PUT /api/planeaciones/:id
func (h *PlaneacionesHandler) UpdatePlaneacion(c *gin.Context) {
	claims, err := h.getUserFromToken(c)
	if err != nil {
		c.JSON(http.StatusUnauthorized, gin.H{"error": err.Error()})
		return
	}

	idStr := c.Param("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil || id <= 0 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "id inválido"})
		return
	}

	var req CreatePlaneacionRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "payload inválido",
			"msg":   err.Error(),
		})
		return
	}

	ctx := c.Request.Context()

	const updateSQL = `
		UPDATE public.planeaciones
		SET
			periodo_escolar = $1,
			plan_estudios_anio = $2,
			semestre_nivel = $3,
			grupos = $4,
			programa_academico = $5,
			academia = $6,
			unidad_aprendizaje_nombre = $7,
			area_formacion = $8,
			modalidad = $9,
			sesiones_por_semestre = $10,
			sesiones_aula = $11,
			sesiones_laboratorio = $12,
			sesiones_clinica = $13,
			sesiones_otro = $14,
			horas_teoria = $15,
			horas_practica = $16,
			horas_aula = $17,
			horas_laboratorio = $18,
			horas_clinica = $19,
			horas_otro = $20,
			horas_total = $21,
			antecedentes = $22,
			laterales = $23,
			subsecuentes = $24,
			ejes_compromiso_social_sustentabilidad = $25,
			ejes_perspectiva_genero = $26,
			ejes_internacionalizacion = $27,
			org_proposito = $28,
			org_estrategia = $29,
			org_metodos = $30,
			plagio_ithenticate = $31,
			plagio_turnitin = $32,
			plagio_otro = $33,
			updated_at = now()
		WHERE id = $34
		  AND usuario_id = $35
		RETURNING
			id,
			usuario_id,
			unidad_id,
			periodo_escolar,
			plan_estudios_anio,
			semestre_nivel,
			grupos,
			programa_academico,
			academia,
			unidad_aprendizaje_nombre,
			area_formacion,
			modalidad,
			sesiones_por_semestre,
			sesiones_aula,
			sesiones_laboratorio,
			sesiones_clinica,
			sesiones_otro,
			horas_teoria,
			horas_practica,
			horas_aula,
			horas_laboratorio,
			horas_clinica,
			horas_otro,
			horas_total,
			antecedentes,
			laterales,
			subsecuentes,
			ejes_compromiso_social_sustentabilidad,
			ejes_perspectiva_genero,
			ejes_internacionalizacion,
			org_proposito,
			org_estrategia,
			org_metodos,
			plagio_ithenticate,
			plagio_turnitin,
			plagio_otro,
			created_at,
			updated_at;
	`

	var p Planeacion

	err = h.DB.QueryRow(
		ctx,
		updateSQL,
		req.PeriodoEscolar,
		req.PlanEstudiosAnio,
		req.SemestreNivel,
		req.Grupos,
		req.ProgramaAcademico,
		req.Academia,
		req.UnidadAprendizajeNombre,
		req.AreaFormacion,
		req.Modalidad,
		req.SesionesPorSemestre,
		req.SesionesAula,
		req.SesionesLaboratorio,
		req.SesionesClinica,
		req.SesionesOtro,
		req.HorasTeoria,
		req.HorasPractica,
		req.HorasAula,
		req.HorasLaboratorio,
		req.HorasClinica,
		req.HorasOtro,
		req.HorasTotal,
		req.Antecedentes,
		req.Laterales,
		req.Subsecuentes,
		req.EjesCompromisoSocialSustentabilidad,
		req.EjesPerspectivaGenero,
		req.EjesInternacionalizacion,
		req.OrgProposito,
		req.OrgEstrategia,
		req.OrgMetodos,
		req.PlagioIthenticate,
		req.PlagioTurnitin,
		req.PlagioOtro,
		id,
		claims.UserID,
	).Scan(
		&p.ID,
		&p.UsuarioID,
		&p.UnidadID,
		&p.PeriodoEscolar,
		&p.PlanEstudiosAnio,
		&p.SemestreNivel,
		&p.Grupos,
		&p.ProgramaAcademico,
		&p.Academia,
		&p.UnidadAprendizajeNombre,
		&p.AreaFormacion,
		&p.Modalidad,
		&p.SesionesPorSemestre,
		&p.SesionesAula,
		&p.SesionesLaboratorio,
		&p.SesionesClinica,
		&p.SesionesOtro,
		&p.HorasTeoria,
		&p.HorasPractica,
		&p.HorasAula,
		&p.HorasLaboratorio,
		&p.HorasClinica,
		&p.HorasOtro,
		&p.HorasTotal,
		&p.Antecedentes,
		&p.Laterales,
		&p.Subsecuentes,
		&p.EjesCompromisoSocialSustentabilidad,
		&p.EjesPerspectivaGenero,
		&p.EjesInternacionalizacion,
		&p.OrgProposito,
		&p.OrgEstrategia,
		&p.OrgMetodos,
		&p.PlagioIthenticate,
		&p.PlagioTurnitin,
		&p.PlagioOtro,
		&p.CreatedAt,
		&p.UpdatedAt,
	)

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "error al actualizar planeación",
			"msg":   err.Error(),
		})
		return
	}

	c.JSON(http.StatusOK, p)
}

func (h *PlaneacionesHandler) DeletePlaneacion(c *gin.Context) {
	c.JSON(http.StatusNotImplemented, gin.H{"error": "no implementado aún"})
}
